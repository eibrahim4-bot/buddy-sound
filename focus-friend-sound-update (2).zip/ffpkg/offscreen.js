// Hidden page that actually makes the noise. Chrome extensions can't play audio from the background
// service worker, so background.js opens this "offscreen document" and sends it play requests.
let audioCtx;
chrome.runtime.onMessage.addListener(m => {
  if (!m || m.target !== 'offscreen' || m.type !== 'sound') return;
  audioCtx = audioCtx || new AudioContext();
  const go = () => playSoundSequence(audioCtx, m.sounds || [], m.volume, m.pitch);
  if (audioCtx.state === 'suspended') audioCtx.resume().then(go).catch(() => {}); else go();
});
