// A tiny synthesizer for the buddy's sounds (no audio files). Runs inside offscreen.html so sounds
// play even when the side panel is closed. Every animal gets its own pitch (see ANIMAL_PITCH in shared.js).

const SOUND_NOTES = {
  // ----- moods -----
  happy:    [{ f: 523.25, t: 0, d: .18, type: 'triangle' }, { f: 659.25, t: .09, d: .18, type: 'triangle' }, { f: 783.99, t: .18, d: .34, type: 'triangle' }],
  okay:     [{ f: 440, t: 0, d: .16 }, { f: 494, t: .12, d: .24, v: .4 }],
  sad:      [{ f: 392, to: 262, t: 0, d: .75, type: 'triangle', v: .45 }, { f: 330, to: 220, t: .25, d: .75, v: .3 }],
  panic:    Array.from({ length: 6 }, (_, i) => ({ f: i % 2 ? 740 : 880, t: i * .08, d: .07, type: 'square', v: .22 })),
  final:    Array.from({ length: 3 }, (_, i) => ({ f: 600, to: 1100, t: i * .28, d: .26, type: 'sawtooth', v: .26 })),
  faint:    [{ f: 700, to: 70, t: 0, d: .95, v: .5 }, { noise: true, t: .9, d: .28, v: .55, lp: 280 }],
  sleeping: [{ f: 392, t: 0, d: .55, v: .25 }, { f: 330, t: .28, d: .55, v: .25 }, { f: 262, t: .56, d: .85, v: .25 }],
  // ----- events -----
  warn:     [{ f: 466, t: 0, d: .14, type: 'triangle', v: .45 }, { f: 370, t: .13, d: .24, type: 'triangle', v: .45 }],   // "uh-oh"
  five:     [0, .5].flatMap(t => [{ f: 880, t, d: .7, v: .4 }, { f: 1760, t, d: .4, v: .15 }, { f: 2637, t, d: .25, v: .08 }]),
  complete: [{ f: 523.25, t: 0, d: .2, type: 'triangle' }, { f: 659.25, t: .12, d: .2, type: 'triangle' }, { f: 783.99, t: .24, d: .2, type: 'triangle' },
             { f: 1046.5, t: .36, d: .8, type: 'triangle' }, { f: 1318.5, t: .4, d: .6, v: .2 }],
  streak:   [523.25, 587.33, 659.25, 783.99, 880, 1046.5, 1174.66, 1318.5].map((f, i) => ({ f, t: i * .07, d: .22, v: .3 })),
  rescue:   [{ f: 200, to: 800, t: 0, d: .35, type: 'triangle', v: .4 }, { f: 784, t: .33, d: .3 }, { f: 1047, t: .45, d: .5, v: .4 }],
  treat:    [...[0, .09, .18].map(t => ({ f: 260, to: 140, t, d: .07, type: 'square', v: .28 })), { f: 880, t: .34, d: .22, type: 'triangle', v: .3 }],
  start:    [{ f: 523.25, to: 783.99, t: 0, d: .14, type: 'triangle', v: .4 }, { f: 1046.5, t: .14, d: .22, v: .3 }]
};
const SOUND_GAP = 1.0;   // seconds between two sounds played together (e.g. complete, then streak)

function soundNote(ctx, dest, t0, n, pitch) {
  const s = t0 + n.t, g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, s);
  g.gain.exponentialRampToValueAtTime(n.v == null ? 0.5 : n.v, s + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, s + n.d);
  if (n.noise) {                                   // short filtered noise burst = a soft "thud"
    const len = Math.max(1, Math.floor(ctx.sampleRate * n.d)), buf = ctx.createBuffer(1, len, ctx.sampleRate), data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    const src = ctx.createBufferSource(), lp = ctx.createBiquadFilter();
    src.buffer = buf; lp.type = 'lowpass'; lp.frequency.value = n.lp || 300;
    src.connect(lp); lp.connect(g); g.connect(dest); src.start(s); src.stop(s + n.d + 0.03);
    return;
  }
  const osc = ctx.createOscillator();
  osc.type = n.type || 'sine';
  osc.frequency.setValueAtTime(n.f * pitch, s);
  if (n.to) osc.frequency.exponentialRampToValueAtTime(n.to * pitch, s + n.d);
  osc.connect(g); g.connect(dest);
  osc.start(s); osc.stop(s + n.d + 0.03);
}

// Schedules one or more sounds. volume is 0-100; pitch ~0.5-1.6 (per animal). Returns how many sounds were scheduled.
function playSoundSequence(ctx, ids, volume, pitch) {
  if (!(volume > 0)) return 0;
  const master = ctx.createGain();
  master.gain.value = Math.pow(Math.min(100, volume) / 100, 2);   // squared curve feels more natural than linear
  master.connect(ctx.destination);
  const p = Math.max(0.5, Math.min(1.6, pitch || 1));
  let t = ctx.currentTime + 0.03, n = 0;
  for (const id of ids) {
    const notes = SOUND_NOTES[id];
    if (!notes) continue;
    notes.forEach(note => soundNote(ctx, master, t, note, p));
    t += SOUND_GAP; n++;
  }
  return n;
}
