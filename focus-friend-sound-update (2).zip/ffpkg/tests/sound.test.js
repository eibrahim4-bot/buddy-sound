// Run with: node tests/sound.test.js   (no dependencies)
const fs = require('fs'), vm = require('vm'), assert = require('assert');
let stored = {};
const ctx = { URL, console, chrome: { storage: { local: { get: async () => stored, set: async () => {} } } } };
vm.createContext(ctx);
const read = f => fs.readFileSync(__dirname + '/../' + f, 'utf8');
vm.runInContext(read('shared.js') + ';this.api={moodKey,planSounds,loadState,SOUND_IDS,ANIMAL_IDS,ANIMAL_PITCH,DEFAULT_STATE,MIN,GRACE};', ctx);
vm.runInContext(read('sound.js') + ';this.snd={SOUND_NOTES,playSoundSequence};', ctx);
const { moodKey, planSounds, loadState, SOUND_IDS, ANIMAL_IDS, ANIMAL_PITCH, DEFAULT_STATE, MIN, GRACE } = ctx.api, { SOUND_NOTES, playSoundSequence } = ctx.snd;

function withHealth(h, status) {   // a state whose session has the requested health (planned 100 min, 20 min allowed to slip)
  const st = DEFAULT_STATE();
  st.session = { goal: 't', plannedMs: 100 * MIN, activeMs: 0, prodMs: 0, distMs: (100 - h) / 100 * 20 * MIN, graceLeft: GRACE, status: status || 'running', cat: 'neutral', overrides: {} };
  return st;
}
const ev = (...types) => types.map((type, i) => ({ id: i + 1, type, text: '' }));

// moods
assert.equal(moodKey(withHealth(100)), 'happy'); assert.equal(moodKey(withHealth(60)), 'okay');
assert.equal(moodKey(withHealth(30)), 'sad'); assert.equal(moodKey(withHealth(10)), 'panic');
assert.equal(moodKey(withHealth(100, 'paused')), 'sleeping'); assert.equal(moodKey(withHealth(0, 'fainted')), 'fainted');
assert.equal(moodKey(DEFAULT_STATE()), 'happy');

// what plays when
assert.deepEqual(planSounds(withHealth(60), [], 'happy'), ['okay']);                 // mood changed to okay
assert.deepEqual(planSounds(withHealth(30), ev('moodSad'), 'okay'), ['sad']);        // event + mood change play ONE sad sound
assert.deepEqual(planSounds(withHealth(100), ev('warn'), 'happy'), ['warn']);        // distracted
assert.deepEqual(planSounds(withHealth(0, 'fainted'), ev('moodFaint', 'warn'), 'panic'), ['faint']);   // fainted beats everything
assert.deepEqual(planSounds(withHealth(5), ev('moodPanic', 'moodFinal'), 'sad'), ['final']);           // most urgent wins
assert.deepEqual(planSounds(DEFAULT_STATE(), ev('complete', 'streak'), 'happy'), ['complete', 'streak']);
assert.deepEqual(planSounds(DEFAULT_STATE(), ev('complete'), 'okay'), ['complete']);
assert.deepEqual(planSounds(DEFAULT_STATE(), [], 'sad'), []);                        // ending a session early stays quiet
assert.deepEqual(planSounds(withHealth(100, 'paused'), [], 'happy'), ['sleeping']);
assert.deepEqual(planSounds(withHealth(60), ev('treat'), 'sad'), ['treat']);
assert.deepEqual(planSounds(withHealth(100), ev('rescue'), 'fainted'), ['rescue']);
assert.deepEqual(planSounds(withHealth(100), [], 'happy'), []);                      // nothing changed, nothing plays
assert.deepEqual(planSounds(withHealth(100), ev('demo'), 'happy'), []);

// every sound exists, every animal has a pitch
for (const id of SOUND_IDS) assert.ok(SOUND_NOTES[id] && SOUND_NOTES[id].length, 'missing sound ' + id);
for (const id of ANIMAL_IDS) assert.ok(ANIMAL_PITCH[id] > 0.5 && ANIMAL_PITCH[id] < 1.6, 'pitch ' + id);

// the synth schedules notes without errors, and volume 0 is silent
function fakeCtx() {
  const made = { osc: 0, noise: 0 };
  const param = () => ({ value: 1, setValueAtTime(v) { assert.ok(v > 0 || v === 1); }, exponentialRampToValueAtTime(v) { assert.ok(v > 0, 'ramp target must be > 0'); } });
  return { made, currentTime: 0, sampleRate: 44100, destination: {},
    createGain: () => ({ gain: param(), connect() {} }),
    createOscillator: () => { made.osc++; return { type: '', frequency: param(), connect() {}, start() {}, stop() {} }; },
    createBuffer: (c, l) => ({ getChannelData: () => new Float32Array(l) }),
    createBufferSource: () => { made.noise++; return { connect() {}, start() {}, stop() {} }; },
    createBiquadFilter: () => ({ frequency: { value: 0 }, connect() {} }) };
}
for (const id of SOUND_IDS) { const c = fakeCtx(); assert.equal(playSoundSequence(c, [id], 60, 1), 1); assert.ok(c.made.osc + c.made.noise > 0, id); }
{ const c = fakeCtx(); assert.equal(playSoundSequence(c, ['happy'], 0, 1), 0); assert.equal(c.made.osc, 0); }       // volume 0
{ const c = fakeCtx(); assert.equal(playSoundSequence(c, ['complete', 'streak', 'nope'], 50, 1.3), 2); }              // unknown ids skipped
{ const c = fakeCtx(); playSoundSequence(c, ['faint'], 80, 0.6); assert.equal(c.made.noise, 1); }                     // the thud

// settings: sounds start muted; old "sound: true" saves become unmuted
(async () => {
  stored = {}; let s = await loadState(); assert.equal(s.settings.muted, true); assert.equal(s.settings.volume, 60);
  stored = { ff: { settings: { sound: true } } }; s = await loadState(); assert.equal(s.settings.muted, false);
  stored = { ff: { settings: { muted: true, sound: true, volume: 30 } } }; s = await loadState(); assert.equal(s.settings.muted, true); assert.equal(s.settings.volume, 30);
  console.log('Sound tests passed (' + SOUND_IDS.length + ' sounds, ' + ANIMAL_IDS.length + ' animal pitches).');
})().catch(e => { console.error(e); process.exit(1); });
